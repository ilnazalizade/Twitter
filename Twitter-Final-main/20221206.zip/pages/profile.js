
import Profile from "../components/Profile";


export default function profile({newsResults, randomUsersResults}) {
    return (
       <Profile/>
    )
}

