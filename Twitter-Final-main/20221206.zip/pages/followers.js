import Follow from "../components/Follow";


export default function followers() {
    return (
        <Follow tab="followers"/>
    )
}

