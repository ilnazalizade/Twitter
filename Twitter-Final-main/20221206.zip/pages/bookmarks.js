import Bookmark from "../components/Bookmark";


export default function bookmarks({newsResults, randomUsersResults}) {
    return (
                <Bookmark/>
    )
}

