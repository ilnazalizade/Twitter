import Follow from "../components/Follow";


export default function following() {
    return (
        <Follow tab="following"/>
    )
}

